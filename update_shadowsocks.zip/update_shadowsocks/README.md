# update-shadow-socks
update server information from some website.
